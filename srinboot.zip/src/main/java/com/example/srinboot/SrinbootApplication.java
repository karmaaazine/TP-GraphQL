package com.example.srinboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SrinbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SrinbootApplication.class, args);
	}

}
